/*
 * The MIT License
 *
 * Copyright 2022 Valentin Georgiev.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package assignment1_appdev2;

import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;
import jdk.nashorn.internal.ir.BreakNode;

// --------------------------------------------------------------------
// Assignment 1
// Written by: Valentin Georgiev
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
public class DiscountSystem {

    public static void main(String[] args) {
        System.out.println(
                "Welcome to the Discount calculator program\n");
        //Creating a customer
        Customer sam = new Customer("Sam");
        // setting member to be true and the memberType to gold
        sam.setMember(true);
        sam.setMemberType("Gold");
        Date date = new Date();

        Visit visitSam = new Visit("Sam", date);    // Creating a Visit object
        visitSam.setProductExpense(100.0);
        visitSam.setServiceExpense(50.0);
        //Printing customer informaton
        System.out.println("Customer name: " + sam.getName() + ", Is Member ?: " + sam.isMember() + ", Membership type: " + sam.getMemberType());
        //Printing visit informaton
        System.out.println("Visit of: " + visitSam.getName() + ", Product expenses: " + visitSam.getProductExpense() + ", Services expenses: " + visitSam.getServiceExpense()
                + ", Total expenses: " + visitSam.getTotalExpense() + "\n");
        //Printing discount rate
        System.out.println("Discount rate : \n" + "Product Discount Rate: " + DiscountRate.getProductDiscountRate(sam.getMemberType()) + "\nService Discount Rate: " + DiscountRate.getServiceDiscountRate(sam.getMemberType()));
        System.out.println(" ");
        //calculate the expense for service and product after the discount
        visitSam.setServiceExpense(visitSam.getServiceExpense() - (DiscountRate.getServiceDiscountRate(sam.getMemberType()) * visitSam.getServiceExpense()));
        visitSam.setProductExpense(visitSam.getProductExpense() - (DiscountRate.getProductDiscountRate(sam.getMemberType()) * visitSam.getProductExpense()));
        //printing the bill after disocunts
        System.out.println("Bill after discounts : \n" + "Product expenses after discount: " + visitSam.getProductExpense()
                + " Service expenses after discount " + visitSam.getServiceExpense() + " Total Expense: " + visitSam.getTotalExpense() + "\n");

    }
}

/**
 * Class customer
 *
 * @author Valentin Georgiev
 */
class Customer {

    private String name;
    private boolean member = false;
    private String memberType;

    public Customer(String name) {
        this.name = name;

    }

    public String getName() {
        return name;
    }

    public boolean isMember() {
        return member;
    }

    public void setMember(boolean member) {
        this.member = member;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    @Override
    public String toString() {
        return "Customer{" + "name=" + name + ", member=" + member + ", memberType=" + memberType + '}';
    }

}

/**
 * Class Visit
 *
 * @author Valentin
 */
class Visit {

    private Customer customer;
    private Date date;
    private double serviceExpense;

    private double productExpense;
    private String name;

    public Visit(String name, Date date) {
        customer = new Customer(name);
        this.date = date;

    }

    public String getName() {
        return customer.getName();
    }

    public double getServiceExpense() {
        return serviceExpense;
    }

    public void setServiceExpense(double serviceExpense) {
        this.serviceExpense = serviceExpense;
    }

    public double getProductExpense() {
        return productExpense;
    }

    public void setProductExpense(double productExpense) {
        this.productExpense = productExpense;
    }

    public double getTotalExpense() {
        double totalExpense = getProductExpense() + getServiceExpense();
        return totalExpense;
    }

}

/**
 * Class DiscountRate
 *
 * @author Valentin Georgiev
 */
class DiscountRate {

    private static double serviceDiscountPremium = 0.2;
    private static double serviceDiscountGold = 0.15;
    private static double serviceDiscountSilver = 0.1;
    private static double productDiscountPremium = 0.1;
    private static double productDiscountGold = 0.1;
    private static double productDiscountSilver = 0.1;

    public static double getServiceDiscountRate(String type) {
        double serviceDiscountRate = 0;
        switch (type) {
            case "Premium":
                serviceDiscountRate = serviceDiscountPremium;
                break;
            case "Gold":
                serviceDiscountRate = serviceDiscountGold;
                break;
            case "Silver":
                serviceDiscountRate = serviceDiscountSilver;
                break;
        }
        return serviceDiscountRate;
    }

    public static double getProductDiscountRate(String type) {
        double productDiscountRate = 0;
        switch (type) {
            case "Premium":
                productDiscountRate = productDiscountPremium;
                break;
            case "Gold":
                productDiscountRate = productDiscountPremium;
                break;
            case "Silver":
                productDiscountRate = productDiscountPremium;
                break;
        }
        return productDiscountRate;
    }
}
