/*
 * The MIT License
 *
 * Copyright 2022 Valentin Georgiev.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package assignment1_appdev2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Valentin Georgiev
 */
public class DiscountRateTest {

    public DiscountRateTest() {
    }

    /**
     * Test of getServiceDiscountRate method, of class DiscountRate.
     */
    @Test
    public void testGetServiceDiscountRate() {
        String type = "Gold";
        double expected = 0.15;
        double actual = DiscountRate.getServiceDiscountRate(type);
        assertEquals(expected, actual, 0.00001);
    }

    /**
     * Test of getProductDiscountRate method, of class DiscountRate.
     */
    @Test
    public void testGetProductDiscountRate() {
        String type = "Gold";
        double expected = 0.1;
        double actual = DiscountRate.getProductDiscountRate(type);
        assertEquals(expected, actual, 0.00001);
    }

}
