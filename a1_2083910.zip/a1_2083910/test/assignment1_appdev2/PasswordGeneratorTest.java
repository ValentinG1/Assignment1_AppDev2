/*
 * The MIT License
 *
 * Copyright 2022 Valentin Georgiev.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package assignment1_appdev2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Valentin Georgiev
 */
public class PasswordGeneratorTest {

    public PasswordGeneratorTest() {
    }

    /**
     * Test of verifyNewLineChar method, of class PasswordGenerator.
     */
    @Test
    public void testVerifyNewLineChar() {
        String word = "Hello\n";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifyNewLineChar(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifySingleChar method, of class PasswordGenerator.
     */
    @Test
    public void testVerifySingleChar() {
        String word = "s";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifySingleChar(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifyEqual method, of class PasswordGenerator.
     */
    @Test
    public void testVerifyEqual() {
        String word = "s";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifySingleChar(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifyLength method, of class PasswordGenerator.
     */
    @Test
    public void testVerifyLength() {
        String word = "thiswordismorethansixteencharacters";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifyLength(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifyUpper method, of class PasswordGenerator.
     */
    @Test
    public void testVerifyUpper() {
        String word = "John";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifyUpper(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifyLower method, of class PasswordGenerator.
     */
    @Test
    public void testVerifyLower() {
        String word = "john";
        boolean expected = true;
        boolean actual = PasswordGenerator.verifyLower(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of verifySpecial method, of class PasswordGenerator.
     */
    @Test
    public void testVerifySpecial() {
        String word = "@";
        boolean expected = false;
        boolean actual = PasswordGenerator.verifyUpper(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of testNewLineOrSingleChar method, of class PasswordGenerator.
     */
    @Test
    public void testTestNewLineOrSingleChar() {
        String word = "a";
        boolean expected = false;
        boolean actual = PasswordGenerator.testNewLineOrSingleChar(word);
        assertEquals(expected, actual);
    }

    /**
     * Test of ConvertToString method, of class PasswordGenerator.
     */
    @Test
    public void testConvertToString() {
        String[] stringArray = {"My", "Name", "Is", "Valentin"};
        String expected = "MyNameIsValentin";
        String actual = PasswordGenerator.ConvertToString(stringArray);
        assertEquals(expected, actual);
    }

}
